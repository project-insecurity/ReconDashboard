# H1
## H2
### H3
#### H4
##### H5
###### H6

1.  Item 1
    1. A corollary to the above item.
    2. Yet another point to consider.
2.  Item 2
    * A corollary that does not need to be ordered.
    * This is indented four spaces
    * You might want to consider making a new list.
3.  Item 3

*This text will be italic*

**This text will be bold**